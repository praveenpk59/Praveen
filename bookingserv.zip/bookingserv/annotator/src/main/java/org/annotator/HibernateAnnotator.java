package org.annotator;

import javax.persistence.Entity;

import org.jsonschema2pojo.AbstractAnnotator;

import com.fasterxml.jackson.databind.JsonNode;
import com.sun.codemodel.JDefinedClass;
import com.sun.codemodel.JFieldVar;

public class HibernateAnnotator extends AbstractAnnotator {

	@Override
	public void propertyField(JFieldVar field, JDefinedClass clazz, String propertyName, JsonNode propertyNode) {
		super.propertyField(field, clazz, propertyName, propertyNode);
		 if (propertyName.equals("entity")) {
	            clazz.annotate(Entity.class);
	        }
	}
}
