package com.paypal.bfs.test.bookingserv.exception;

public class DuplicateEntryException extends Exception {

	
	private  String message;
	
	 public DuplicateEntryException(String messString
			 ) {
       this.message = messString;
	 }
	
	@Override
	public String getMessage() {
		return message;
	}
}
