package com.paypal.bfs.test.bookingserv.impl;

import com.paypal.bfs.test.bookingserv.api.BookingResource;
import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.exception.BookingServException;
import com.paypal.bfs.test.bookingserv.exception.DuplicateEntryException;
import com.paypal.bfs.test.bookingserv.service.BookingService;

import java.util.List;

import javax.validation.ValidationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookingResourceImpl implements BookingResource {

	
	@Autowired
	private BookingService bookingService;
	
    @Override
    public ResponseEntity<Object> create( @RequestBody Booking booking) {
    	
    	try {
    		
    		validate(booking);
    	
    	     return ResponseEntity.ok(bookingService.createBooking(booking));
    
	    } 
		  catch (DuplicateEntryException e) {
		  
		  ResponseEntity<Object> responseEntity = new
		  ResponseEntity<Object>(e.getMessage(),null,HttpStatus.CONFLICT);
		  
		  return responseEntity; }
		 
    	
    	catch (ValidationException e) {
    		 ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(e.getMessage(),null,HttpStatus.BAD_REQUEST);
  		   
			  return responseEntity;
    	}
    	
    	catch (BookingServException e) {
    		
    		   ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(e.getMessage(),null,HttpStatus.INTERNAL_SERVER_ERROR);
    		   
    			  return responseEntity;
    	}	
    }

	private void validate(Booking booking) {

		  if(booking.getFirstName() == null || booking.getFirstName().equals("")) {
			  throw new ValidationException(" firstName is required");
		  } 
		  
		  if(booking.getLastName() == null || booking.getLastName().equals("")) {
			  throw new ValidationException(" firstName is required");
		  } 
		  
	}

	@Override
	public ResponseEntity<Object> getBookings() {
		try {
		
		 List<Booking> bookings = bookingService.getAllBookings();
		
		  return ResponseEntity.ok(bookings);
	   } catch (BookingServException e) {
		   
		   ResponseEntity<Object> responseEntity = new ResponseEntity<Object>(e.getMessage(),null,HttpStatus.INTERNAL_SERVER_ERROR);
		   
		  return responseEntity;
	   }
	}
}
