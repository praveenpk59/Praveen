package com.paypal.bfs.test.bookingserv.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Service;

import com.paypal.bfs.test.bookingserv.api.model.Booking;
import com.paypal.bfs.test.bookingserv.exception.BookingServException;
import com.paypal.bfs.test.bookingserv.exception.DuplicateEntryException;
import com.paypal.bfs.test.bookingserv.util.HibernateUtil;
import com.paypal.bfs.test.bookingserv.util.NameComparator;

@Service
public class BookingService {

	 // @Autowired private BookingRepository bookingRepository;
	  
	 // @Autowired private AddressRepository addressRepository;
	 
	public Booking createBooking(Booking booking) throws BookingServException, DuplicateEntryException {
		
		
		 Transaction transaction = null;
		 Session session = null;
	        try  {
	        	
	        	session = HibernateUtil.getSessionFactory().openSession();
	            // start a transaction
	            transaction = session.beginTransaction();
	            // save the student objects
	            
	            List<Booking> retrieveBookings = getAllBookings();
	            
	            checkDuplicateResource(retrieveBookings, booking);
	            
	            session.save(booking);
	            int bookingId = booking.getBookingId();
	             booking.getAddress().setBooking(bookingId);
	            // commit transaction
	            transaction.commit();
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            
	            if(e instanceof DuplicateEntryException) {
	            	throw new DuplicateEntryException(e.getMessage());
	            }
	            
	            throw new BookingServException(e.getMessage());
	        }finally {
	        	session.close();
	        }
		
		return booking;
	}
	
	private void checkDuplicateResource(List<Booking> retrieveBookings, Booking booking) throws DuplicateEntryException {

		NameComparator nc = new  NameComparator();
		
		for(Booking b : retrieveBookings) {
			
		  int value = nc.compare(b, booking);
		  if(value == 0) {
			  String message = " Duplicate Resource FirstName " + booking.getFirstName() + " LastName " + booking.getLastName() + "  Date Of Birth " + booking.getDateOfBirth() ;
			  throw new DuplicateEntryException(message);
		  }
		}
		
	}

	public List<Booking> getAllBookings() throws BookingServException {
		
		List<Booking> bookings = new ArrayList<Booking>();
		

		 Transaction transaction = null;
		 Session session = null;
	        try  {
	        	 session = HibernateUtil.getSessionFactory().openSession();
	            // start a transaction
	            transaction = session.beginTransaction();
	             
	           bookings =  session
	             .createQuery(
	                 "select b " +
	                 "from Booking b " +
	                 "join fetch b.address a ", Booking.class).list();
	             
	            transaction.commit();
	            
	            return bookings;
	        } catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	            }
	            throw new BookingServException(e.getMessage());
	        }finally {
				session.close();
			}
		
		//bookingRepository.findAll().forEach(bookings::add);
	}
	
}
