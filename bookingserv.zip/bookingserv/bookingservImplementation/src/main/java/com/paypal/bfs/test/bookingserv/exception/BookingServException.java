package com.paypal.bfs.test.bookingserv.exception;

public class BookingServException extends Exception {
	
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
   public BookingServException(String message) {
   this.message = message;
   }
	
}
