package com.paypal.bfs.test.bookingserv.util;


import java.text.DateFormat;
import java.text.SimpleDateFormat;

import org.springframework.util.comparator.InstanceComparator;

import com.paypal.bfs.test.bookingserv.api.model.Booking;

public class NameComparator extends  InstanceComparator<Booking> {

	@Override
	public int compare(Booking o1, Booking o2) {
		// TODO Auto-generated method stub
		if(o1.getFirstName().equalsIgnoreCase(o2.getFirstName()) || o1.getLastName().equalsIgnoreCase(o2.getLastName())) {
			return 0;
		}
		
		DateFormat f = new SimpleDateFormat();
		
		
		if(o1.getDateOfBirth().toGMTString().compareTo(o2.getDateOfBirth().toGMTString()) == 0) {
			return 0;
		}
		return 2;
		
	}
	
}
