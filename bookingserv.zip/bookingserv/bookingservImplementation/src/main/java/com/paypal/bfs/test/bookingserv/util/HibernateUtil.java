package com.paypal.bfs.test.bookingserv.util;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {

	
//	  Configuration configuration = new Configuration().configure();
//      ServiceRegistry registry = (ServiceRegistry) new StandardServiceRegistryBuilder();
//      ((StandardServiceRegistryBuilder) registry).applySettings(configuration.getProperties());
//      ServiceRegistry serviceRegistry = registry.getParentServiceRegistry();
//       
//      // builds a session factory from the service registry
//      SessionFactory sessionFactory = configuration.buildSessionFactory(serviceRegistry);
//       
//      // obtains the session
//      Session session = sessionFactory.openSession();
//      session.beginTransaction();
//      
//      session.save(booking);
//      session.getTransaction().commit();
//      session.close(); 
	
	
	private static StandardServiceRegistry registry;
    private static SessionFactory sessionFactory;

    public static SessionFactory getSessionFactory() {
        if (sessionFactory == null) {
            try {
                // Create registry
                registry = new StandardServiceRegistryBuilder().configure().build();

                // Create MetadataSources
                MetadataSources sources = new MetadataSources(registry);

                // Create Metadata
                Metadata metadata = sources.getMetadataBuilder().build();

                // Create SessionFactory
                sessionFactory = metadata.getSessionFactoryBuilder().build();

            } catch (Exception e) {
                e.printStackTrace();
                if (registry != null) {
                    StandardServiceRegistryBuilder.destroy(registry);
                }
            }
        }
        return sessionFactory;
	
}
    
}
