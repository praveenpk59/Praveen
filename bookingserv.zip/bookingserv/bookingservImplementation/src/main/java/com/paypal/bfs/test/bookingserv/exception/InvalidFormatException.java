package com.paypal.bfs.test.bookingserv.exception;

public class InvalidFormatException  extends BookingServException{

	public InvalidFormatException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
