package com.booking.BookingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
